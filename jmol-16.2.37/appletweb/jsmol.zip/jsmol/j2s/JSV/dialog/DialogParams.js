Clazz.declarePackage("JSV.dialog");
(function(){
var c$ = Clazz.declareType(JSV.dialog, "DialogParams", null);
})();
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
