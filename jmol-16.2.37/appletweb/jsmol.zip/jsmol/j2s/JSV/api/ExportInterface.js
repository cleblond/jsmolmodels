Clazz.declarePackage("JSV.api");
Clazz.declareInterface(JSV.api, "ExportInterface", JSV.api.JSVExporter);
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
