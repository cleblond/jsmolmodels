Clazz.declarePackage("JSV.api.js");
Clazz.declareInterface(JSV.api.js, "JSVToJSmolInterface", javajs.api.js.J2SObjectInterface);
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
