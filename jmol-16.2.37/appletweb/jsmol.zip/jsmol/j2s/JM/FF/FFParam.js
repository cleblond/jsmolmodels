Clazz.declarePackage("JM.FF");
(function(){
var c$ = Clazz.decorateAsClass(function(){
this.iVal = null;
this.dVal = null;
this.sVal = null;
Clazz.instantialize(this, arguments);}, JM.FF, "FFParam", null);
})();
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
