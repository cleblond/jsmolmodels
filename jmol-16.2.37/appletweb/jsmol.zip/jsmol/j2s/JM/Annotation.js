Clazz.declarePackage("JM");
Clazz.load(["JM.ProteinStructure"], "JM.Annotation", null, function(){
var c$ = Clazz.declareType(JM, "Annotation", JM.ProteinStructure);
});
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
