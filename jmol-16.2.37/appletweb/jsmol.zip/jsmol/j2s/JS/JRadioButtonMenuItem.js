Clazz.declarePackage("JS");
Clazz.load(["JS.JMenuItem"], "JS.JRadioButtonMenuItem", null, function(){
var c$ = Clazz.decorateAsClass(function(){
this.isRadio = true;
Clazz.instantialize(this, arguments);}, JS, "JRadioButtonMenuItem", JS.JMenuItem);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor(this, JS.JRadioButtonMenuItem, ["rad", 3]);
});
});
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
