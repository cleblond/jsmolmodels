Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.FlowLayout", null, function(){
var c$ = Clazz.declareType(JS, "FlowLayout", JS.LayoutManager);
});
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
