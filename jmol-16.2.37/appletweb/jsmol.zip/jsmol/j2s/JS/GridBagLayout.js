Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.GridBagLayout", null, function(){
var c$ = Clazz.declareType(JS, "GridBagLayout", JS.LayoutManager);
});
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
