Clazz.declarePackage("JS");
Clazz.load(["JS.JComponent"], "JS.JComponentImp", null, function(){
var c$ = Clazz.declareType(JS, "JComponentImp", JS.JComponent);
Clazz.overrideMethod(c$, "toHTML", 
function(){
return null;
});
});
;//5.0.1-v4 Wed Oct 09 10:23:43 CDT 2024
